
    <div>
    <a href="form.html">
  <button type="submit" class="bt bt-b1 mt-1">Solicitar proposta online <i class="fas fa-paper-plane"></i></button>
</a>

        <p class="mb-0" style="line-height: inherit; font-size: small;"><small>Os dados captados nesse formulário não serão utilizados por terceiros, apenas para uso interno de acordo com a LGPD. Ao enviar sua mensagem você concorda com nossa política de privacidade.</small></p>
    
    </div>
>
</form>